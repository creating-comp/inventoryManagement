from flask import Flask, render_template, request, jsonify
import pandas as pd
import joblib
import numpy as np
from tensorflow.keras.models import load_model
from datetime import datetime, timedelta
import os

app = Flask(__name__)

# Yollar
MODEL_PATH = "models/lstm_model_product1.h5"
SCALER_PATH = "models/scaler_product1.pkl"
DATA_PATH = "train.csv"  # CSV dosyan: date,store,item,sales başlıklı

# Model ve scaler yükle
if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(f"Model bulunamadı: {MODEL_PATH}")
if not os.path.exists(SCALER_PATH):
    raise FileNotFoundError(f"Scaler bulunamadı: {SCALER_PATH}")
if not os.path.exists(DATA_PATH):
    raise FileNotFoundError(f"Veri dosyası bulunamadı: {DATA_PATH}")

model = load_model(MODEL_PATH, compile=False)
scaler = joblib.load(SCALER_PATH)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/forecast', methods=['POST'])
def forecast():
    try:
        item_id = int(request.form['item_id'])
        store_id = int(request.form['store_id'])

        sales_data = pd.read_csv(DATA_PATH)

        # ✅ Kolon adlarını uyumlu hale getir
        sales_data.rename(columns={"item": "item_id", "store": "store_id"}, inplace=True)

        df = sales_data[(sales_data['item_id'] == item_id) & (sales_data['store_id'] == store_id)]
        df = df.sort_values('date')

        if df.empty or len(df) < 30:
            return jsonify({"error": "Yeterli veri yok."})

        df['sales'] = scaler.transform(df[['sales']])
        lookback = 30
        last_30 = df['sales'].values[-lookback:]
        X_input = np.array(last_30).reshape(1, lookback, 1)

        prediction = model.predict(X_input)
        predicted_sales = scaler.inverse_transform(prediction)[0].tolist()

        last_date = datetime.strptime(df['date'].iloc[-1], "%Y-%m-%d")
        future_dates = [(last_date + timedelta(days=i+1)).strftime("%Y-%m-%d") for i in range(len(predicted_sales))]

        result = [{"date": d, "sales": s} for d, s in zip(future_dates, predicted_sales)]
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
