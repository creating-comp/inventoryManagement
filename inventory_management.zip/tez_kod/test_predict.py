import numpy as np
import pandas as pd
import joblib
from datetime import datetime, timedelta
from tensorflow.keras.models import load_model
import os

# Dosya yolları
model_path = "models/lstm_model_product1.h5"
scaler_path = "models/scaler_product1.pkl"
data_path = "train.csv"

# Kontrol
if not os.path.exists(model_path):
    raise FileNotFoundError(f"Model bulunamadı: {model_path}")
if not os.path.exists(scaler_path):
    raise FileNotFoundError(f"Scaler bulunamadı: {scaler_path}")
if not os.path.exists(data_path):
    raise FileNotFoundError(f"Veri bulunamadı: {data_path}")

# Veri yükle
sales_data = pd.read_csv(data_path)
sales_data.rename(columns={"item": "item_id", "store": "store_id"}, inplace=True)

# Filtrele
item_id = 1
store_id = 1

df = sales_data[(sales_data['item_id'] == item_id) & (sales_data['store_id'] == store_id)]
df = df.sort_values('date')

if df.empty or len(df) < 30:
    raise ValueError("Yeterli veri yok!")

# Model ve scaler yükle
model = load_model(model_path, compile=False)
scaler = joblib.load(scaler_path)

# Normalizasyon ve tahmin
df['sales'] = scaler.transform(df[['sales']])
last_30 = df['sales'].values[-30:]
X_input = np.array(last_30).reshape(1, 30, 1)

prediction = model.predict(X_input)
predicted_sales = scaler.inverse_transform(prediction)[0].tolist()

last_date = datetime.strptime(df['date'].iloc[-1], "%Y-%m-%d")
future_dates = [(last_date + timedelta(days=i+1)).strftime("%Y-%m-%d") for i in range(len(predicted_sales))]

# Yazdır
print("\n📈 Gelecek Günler için Tahmin:")
for date, sale in zip(future_dates, predicted_sales):
    print(f"{date} → {sale:.2f}")
