import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
import joblib
import os

# Dosya yolları
DATA_PATH = "train.csv"
MODEL_PATH = "models/lstm_model_product1.h5"
SCALER_PATH = "models/scaler_product1.pkl"

# Veriyi oku
df = pd.read_csv(DATA_PATH)
df['date'] = pd.to_datetime(df['date'])

# Ürün ve mağaza seçimi
product_id = 1
store_id = 1
df = df[(df['item'] == product_id) & (df['store'] == store_id)].sort_values('date')

# Satışları normalleştir
scaler = MinMaxScaler()
sales = df[['sales']]
sales_scaled = scaler.fit_transform(sales)

# 30 günlük sliding window
X, y = [], []
lookback = 30
for i in range(len(sales_scaled) - lookback):
    X.append(sales_scaled[i:i + lookback])
    y.append(sales_scaled[i + lookback])
X, y = np.array(X), np.array(y)

# LSTM Model
model = Sequential()
model.add(LSTM(64, activation='tanh', input_shape=(lookback, 1)))
model.add(Dense(1))
model.compile(optimizer='adam', loss='mse')

# Eğit
model.fit(X, y, epochs=50, verbose=1)

# Modeli kaydet
os.makedirs("models", exist_ok=True)
model.save(MODEL_PATH)
joblib.dump(scaler, SCALER_PATH)

print(f"✅ Model ve scaler kaydedildi: {MODEL_PATH}, {SCALER_PATH}")
