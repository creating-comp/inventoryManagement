import sys
import os
import psycopg2
import pandas as pd
import numpy as np
import joblib
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem, QMessageBox
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt

class ForecastApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Satış Tahmini Uygulaması")
        self.setGeometry(100, 100, 1000, 600)

        self.item_label = QLabel("Ürün ID:")
        self.item_input = QLineEdit()
        self.store_label = QLabel("Mağaza ID:")
        self.store_input = QLineEdit()
        self.predict_button = QPushButton("Tahmin Et")
        self.predict_button.clicked.connect(self.predict)

        self.table = QTableWidget()
        self.figure, self.ax = plt.subplots()
        self.canvas = FigureCanvas(self.figure)

        form_layout = QHBoxLayout()
        form_layout.addWidget(self.item_label)
        form_layout.addWidget(self.item_input)
        form_layout.addWidget(self.store_label)
        form_layout.addWidget(self.store_input)
        form_layout.addWidget(self.predict_button)

        main_layout = QVBoxLayout()
        main_layout.addLayout(form_layout)
        main_layout.addWidget(self.canvas)
        main_layout.addWidget(self.table)

        self.setLayout(main_layout)

    def predict(self):
        try:
            item_id = int(self.item_input.text())
            store_id = int(self.store_input.text())
        except ValueError:
            QMessageBox.warning(self, "Hata", "Geçerli ID giriniz.")
            return

        try:
            df = pd.read_csv("train.csv", parse_dates=["date"])
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"train.csv yüklenemedi:\n{e}")
            return

        df_item = df[(df["item"] == item_id) & (df["store"] == store_id)].copy()
        if df_item.empty:
            QMessageBox.warning(self, "Hata", "Veri bulunamadı.")
            return

        panel = df_item.groupby("date", as_index=False)["sales"].sum()
        panel["dow"] = panel.date.dt.dayofweek
        panel["month"] = panel.date.dt.month
        panel["day"] = panel.date.dt.day
        panel["is_weekend"] = (panel.dow >= 5).astype(int)
        panel["dow_sin"] = np.sin(2 * np.pi * panel.dow / 7)
        panel["dow_cos"] = np.cos(2 * np.pi * panel.dow / 7)
        panel["month_sin"] = np.sin(2 * np.pi * (panel.month - 1) / 12)
        panel["month_cos"] = np.cos(2 * np.pi * (panel.month - 1) / 12)

        for lag in [1, 3, 7, 14, 30]:
            panel[f"lag_{lag}"] = panel["sales"].shift(lag)
        for w in [7, 14, 30]:
            panel[f"roll_mean_{w}"] = panel["sales"].shift(1).rolling(w).mean()

        panel.dropna(inplace=True)

        try:
            model = joblib.load(f"models/lgbm_model_item{item_id}_store{store_id}.pkl")
            scaler = joblib.load(f"models/scaler_item{item_id}_store{store_id}.pkl")
        except Exception as e:
            QMessageBox.critical(self, "Model Hatası", f"Model veya scaler yüklenemedi:\n{e}")
            return

        last_dates = sorted(panel["date"].unique())[-90:]
        test_panel = panel[panel["date"].isin(last_dates)].copy()

        try:
            X_test = test_panel.drop(["date", "sales"], axis=1)
            y_true = test_panel["sales"].values.reshape(-1, 1)
            y_true_scaled = scaler.transform(y_true).ravel()

            y_pred_scaled = model.predict(X_test)
            y_pred = scaler.inverse_transform(y_pred_scaled.reshape(-1, 1)).ravel()
            test_panel["pred"] = y_pred
        except Exception as e:
            QMessageBox.critical(self, "Tahmin Hatası", f"Tahmin sırasında hata oluştu:\n{e}")
            return

        rmse_norm = np.sqrt(np.mean((y_true_scaled - y_pred_scaled) ** 2))
        rmse_orig = np.sqrt(np.mean((y_true.ravel() - y_pred) ** 2))

        self.ax.clear()
        self.ax.plot(test_panel["date"], test_panel["sales"], label="Gerçek")
        self.ax.plot(test_panel["date"], test_panel["pred"], label="Tahmin")
        self.ax.set_title(f"Ürün {item_id} - Mağaza {store_id}\nRMSE (norm): {rmse_norm:.4f} | RMSE (gerçek): {rmse_orig:.2f}")
        self.ax.legend()
        self.canvas.draw()

        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Tarih", "Gerçek", "Tahmin", "Hata"])
        self.table.setRowCount(len(test_panel))

        for i, (idx, row) in enumerate(test_panel.iterrows()):
            self.table.setItem(i, 0, QTableWidgetItem(str(row["date"].date())))
            self.table.setItem(i, 1, QTableWidgetItem(f"{row['sales']:.2f}"))
            self.table.setItem(i, 2, QTableWidgetItem(f"{row['pred']:.2f}"))
            self.table.setItem(i, 3, QTableWidgetItem(f"{row['pred'] - row['sales']:.2f}"))

        # CSV olarak da kaydet
        try:
            os.makedirs("results", exist_ok=True)
            csv_path = "results/all_forecasts.csv"
            write_header = not os.path.exists(csv_path)
            test_panel.to_csv(csv_path, mode="a", header=write_header, index=False)

        except Exception as e:
            QMessageBox.warning(self, "CSV Hatası", f"CSV kaydı başarısız:\n{e}")

        # Veritabanına kayıt
        try:
            conn = psycopg2.connect(
                host="localhost", database="salesdb",
                user="postgres", password="postgres", port=5432
            )
            cur = conn.cursor()
            for _, row in test_panel.iterrows():
                cur.execute("""
                    INSERT INTO forecast_results (item_id, store_id, date, real_sales, predicted_sales, rmse, rmse_orig)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """, (
                    int(item_id), int(store_id),
                    row["date"].date(), float(row["sales"]), float(row["pred"]),
                    float(rmse_norm), float(rmse_orig)
                ))
            conn.commit()
            cur.close()
            conn.close()
            QMessageBox.information(self, "Başarılı", "Sonuçlar veritabanına ve CSV dosyasına kaydedildi.")
        except Exception as e:
         print("Veritabanı hatası:", e)
         QMessageBox.warning(self, "DB Hatası", "Veritabanına kaydedilemedi (detay terminalde).")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ForecastApp()
    window.show()
    sys.exit(app.exec_())
