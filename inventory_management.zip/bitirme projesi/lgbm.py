import os
import joblib
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import warnings

warnings.filterwarnings("ignore")
np.random.seed(42)

DATA_PATH = "train.csv"
SAVE_DIR = "models"
os.makedirs(SAVE_DIR, exist_ok=True)

df = pd.read_csv(DATA_PATH, parse_dates=["date"])
item_store_pairs = df.groupby(["item", "store"]).size().reset_index().iloc[:, :2].values

for item_id, store_id in item_store_pairs:
    df_item = df[(df["item"] == item_id) & (df["store"] == store_id)].copy()
    panel = df_item.groupby("date", as_index=False)["sales"].sum()

    panel["dow"] = panel.date.dt.dayofweek
    panel["month"] = panel.date.dt.month
    panel["day"] = panel.date.dt.day
    panel["is_weekend"] = (panel.dow >= 5).astype(int)

    panel["dow_sin"] = np.sin(2 * np.pi * panel.dow / 7)
    panel["dow_cos"] = np.cos(2 * np.pi * panel.dow / 7)
    panel["month_sin"] = np.sin(2 * np.pi * (panel.month - 1) / 12)
    panel["month_cos"] = np.cos(2 * np.pi * (panel.month - 1) / 12)

    for lag in [1, 3, 7, 14, 30]:
        panel[f"lag_{lag}"] = panel["sales"].shift(lag)
    for w in [7, 14, 30]:
        panel[f"roll_mean_{w}"] = panel["sales"].shift(1).rolling(w).mean()

    panel.dropna(inplace=True)

    if len(panel) < 100:
        continue

    last_dates = sorted(panel["date"].unique())[-90:]
    train = panel[~panel["date"].isin(last_dates)]
    test = panel[panel["date"].isin(last_dates)]

    X_train = train.drop(["date", "sales"], axis=1)
    y_train = train["sales"].values.reshape(-1, 1)
    X_test = test.drop(["date", "sales"], axis=1)
    y_test = test["sales"].values.reshape(-1, 1)

    scaler = MinMaxScaler()
    y_train_scaled = scaler.fit_transform(y_train).ravel()
    y_test_scaled = scaler.transform(y_test).ravel()

    model = lgb.LGBMRegressor(
        n_estimators=2000,
        learning_rate=0.01,
        num_leaves=128,
        subsample=0.9,
        colsample_bytree=0.9,
        random_state=42
    )

    model.fit(
        X_train, y_train_scaled,
        eval_set=[(X_test, y_test_scaled)],
        eval_metric="rmse",
        callbacks=[lgb.early_stopping(stopping_rounds=100), lgb.log_evaluation(0)]
    )

    y_pred_scaled = model.predict(X_test)
    y_pred = scaler.inverse_transform(y_pred_scaled.reshape(-1, 1)).ravel()
    rmse = np.sqrt(mean_squared_error(y_test.ravel(), y_pred))

    print(f"Egitildi: item {item_id}, store {store_id} -> RMSE: {rmse:.2f}")

    joblib.dump(model, f"{SAVE_DIR}/lgbm_model_item{item_id}_store{store_id}.pkl")
    joblib.dump(scaler, f"{SAVE_DIR}/scaler_item{item_id}_store{store_id}.pkl")
