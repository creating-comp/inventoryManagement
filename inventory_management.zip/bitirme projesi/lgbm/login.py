import psycopg2
from PyQt5.QtWidgets import QDialog, QMessageBox
from login_ui import Ui_LoginWindow

class LoginWindow(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = Ui_LoginWindow()
        self.ui.setupUi(self)

        self.ui.loginButton.clicked.connect(self.check_login)

    def check_login(self):
        username = self.ui.usernameInput.text()
        password = self.ui.passwordInput.text()

        try:
            conn = psycopg2.connect(
                dbname="salesdb",
                user="postgres",
                password="postgres",
                host="localhost",
                port="5432"
            )
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
            result = cur.fetchone()
            conn.close()

            if result:
                self.accept()  # QDialog yöntemiyle pencereyi başarıyla kapatır
            else:
                self.ui.loginStatusLabel.setText("❌ Hatalı kullanıcı adı veya şifre")
                self.ui.loginStatusLabel.setStyleSheet("color: red;")

        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Veritabanı bağlantısı başarısız:\n{e}")
