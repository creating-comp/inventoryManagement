import sys
import os
import pandas as pd
import numpy as np
import joblib
import psycopg2
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import MinMaxScaler
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (
    QApplication, QWidget, QTableWidgetItem, QMessageBox, QFileDialog
)
from PyQt5.QtCore import QThread, pyqtSignal
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt

from tahmin2_ui import Ui_Form
from stock_window import StockWindow  # Stok ekranı

class TrainWorker(QThread):
    finished = pyqtSignal(str)

    def __init__(self, csv_path):
        super().__init__()
        self.csv_path = csv_path

    def run(self):
        try:
            import lightgbm as lgb
            df = pd.read_csv(self.csv_path, parse_dates=["date"])
            item_store_pairs = df.groupby(["item", "store"]).size().reset_index().iloc[:, :2].values
            os.makedirs("models", exist_ok=True)

            for item_id, store_id in item_store_pairs:
                df_item = df[(df["item"] == item_id) & (df["store"] == store_id)].copy()
                panel = df_item.groupby("date", as_index=False)["sales"].sum()

                panel["dow"] = panel.date.dt.dayofweek
                panel["month"] = panel.date.dt.month
                panel["day"] = panel.date.dt.day
                panel["is_weekend"] = (panel.dow >= 5).astype(int)
                panel["dow_sin"] = np.sin(2 * np.pi * panel.dow / 7)
                panel["dow_cos"] = np.cos(2 * np.pi * panel.dow / 7)
                panel["month_sin"] = np.sin(2 * np.pi * (panel.month - 1) / 12)
                panel["month_cos"] = np.cos(2 * np.pi * (panel.month - 1) / 12)

                for lag in [1, 3, 7, 14, 30]:
                    panel[f"lag_{lag}"] = panel["sales"].shift(lag)
                for w in [7, 14, 30]:
                    panel[f"roll_mean_{w}"] = panel["sales"].shift(1).rolling(w).mean()
                panel.dropna(inplace=True)
                if len(panel) < 100:
                    continue

                last_dates = sorted(panel["date"].unique())[-90:]
                train = panel[~panel["date"].isin(last_dates)]
                test = panel[panel["date"].isin(last_dates)]

                X_train = train.drop(["date", "sales"], axis=1)
                y_train = train["sales"].values.reshape(-1, 1)
                X_test = test.drop(["date", "sales"], axis=1)
                y_test = test["sales"].values.reshape(-1, 1)

                scaler = MinMaxScaler()
                y_train_scaled = scaler.fit_transform(y_train).ravel()
                y_test_scaled = scaler.transform(y_test).ravel()

                model = lgb.LGBMRegressor(
                    n_estimators=2000,
                    learning_rate=0.01,
                    num_leaves=128,
                    subsample=0.9,
                    colsample_bytree=0.9,
                    random_state=42
                )

                model.fit(
                    X_train, y_train_scaled,
                    eval_set=[(X_test, y_test_scaled)],
                    eval_metric="rmse",
                    callbacks=[lgb.early_stopping(100), lgb.log_evaluation(0)]
                )

                joblib.dump(model, f"models/lgbm_model_item{item_id}_store{store_id}.pkl")
                joblib.dump(scaler, f"models/scaler_item{item_id}_store{store_id}.pkl")

            self.finished.emit("✅ Eğitim tamamlandı ve modeller kaydedildi.")
        except Exception as e:
            self.finished.emit(f"❌ Eğitim sırasında hata: {e}")

class ForecastApp(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)

        self.figure, self.ax = plt.subplots()
        self.canvas = FigureCanvas(self.figure)
        layout = QtWidgets.QVBoxLayout(self.ui.plotWidget)
        layout.addWidget(self.canvas)

        self.ui.predictButton.clicked.connect(self.predict)
        self.ui.openStockButton.clicked.connect(self.open_stock_window)
        self.ui.trainModelButton.clicked.connect(self.train_models)

    def train_models(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "CSV Dosyası Seç", "", "CSV Files (*.csv)")
        if not file_path:
            self.ui.resultLabel.setText("⚠️ Dosya seçilmedi.")
            return
        self.ui.resultLabel.setText("📊 Model eğitimi başlatılıyor...")
        self.train_worker = TrainWorker(file_path)
        self.train_worker.finished.connect(self.training_finished)
        self.train_worker.start()

    def training_finished(self, message):
        self.ui.resultLabel.setStyleSheet("background-color:#D0F0C0; color:#2E7D32;")
        self.ui.resultLabel.setText(message)

    def open_stock_window(self):
        self.stock_window = StockWindow()
        self.stock_window.show()

    def predict(self):
        try:
            item_id = int(self.ui.itemInput.text())
            store_id = int(self.ui.storeInput.text())
            stock = int(self.ui.stockInput.text())
        except ValueError:
            self.ui.resultLabel.setStyleSheet("background-color:#FFCDD2; color:#C62828;")
            self.ui.resultLabel.setText("❌ Geçerli sayılar giriniz.")
            return

        try:
            df = pd.read_csv("train.csv", parse_dates=["date"])
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"train.csv yüklenemedi:\n{e}")
            return

        df_item = df[(df["item"] == item_id) & (df["store"] == store_id)].copy()
        if df_item.empty:
            self.ui.resultLabel.setText("❌ Ürün/Mağaza için veri bulunamadı.")
            return

        panel = df_item.groupby("date", as_index=False)["sales"].sum()
        panel["dow"] = panel.date.dt.dayofweek
        panel["month"] = panel.date.dt.month
        panel["day"] = panel.date.dt.day
        panel["is_weekend"] = (panel.dow >= 5).astype(int)
        panel["dow_sin"] = np.sin(2 * np.pi * panel.dow / 7)
        panel["dow_cos"] = np.cos(2 * np.pi * panel.dow / 7)
        panel["month_sin"] = np.sin(2 * np.pi * (panel.month - 1) / 12)
        panel["month_cos"] = np.cos(2 * np.pi * (panel.month - 1) / 12)

        for lag in [1, 3, 7, 14, 30]:
            panel[f"lag_{lag}"] = panel["sales"].shift(lag)
        for w in [7, 14, 30]:
            panel[f"roll_mean_{w}"] = panel["sales"].shift(1).rolling(w).mean()
        panel.dropna(inplace=True)

        try:
            model = joblib.load(f"models/lgbm_model_item{item_id}_store{store_id}.pkl")
            scaler = joblib.load(f"models/scaler_item{item_id}_store{store_id}.pkl")
        except Exception as e:
            self.ui.resultLabel.setText(f"❌ Model yüklenemedi:\n{e}")
            return

        last_dates = sorted(panel["date"].unique())[-90:]
        test_panel = panel[panel["date"].isin(last_dates)].copy()

        try:
            X_test = test_panel.drop(["date", "sales"], axis=1)
            y_true = test_panel["sales"].values.reshape(-1, 1)
            y_true_scaled = scaler.transform(y_true).ravel()
            y_pred_scaled = model.predict(X_test)
            y_pred = scaler.inverse_transform(y_pred_scaled.reshape(-1, 1)).ravel()
            test_panel["pred"] = y_pred
        except Exception as e:
            self.ui.resultLabel.setText(f"❌ Tahmin yapılamadı:\n{e}")
            return

        rmse_norm = np.sqrt(np.mean((y_true_scaled - y_pred_scaled) ** 2))
        rmse_orig = np.sqrt(mean_squared_error(y_true.ravel(), y_pred))

        self.ax.clear()
        self.ax.plot(test_panel["date"], test_panel["sales"], label="Gerçek")
        self.ax.plot(test_panel["date"], test_panel["pred"], label="Tahmin")
        self.ax.legend()
        self.canvas.draw()

        self.ui.resultLabel.setStyleSheet("background-color:#D0F0C0; color:#2E7D32;")
        self.ui.resultLabel.setText(f"✅ RMSE: {rmse_orig:.2f} | Normalize RMSE: {rmse_norm:.4f}")

        self.ui.table.setRowCount(len(test_panel))
        self.ui.table.setColumnCount(5)
        self.ui.table.setHorizontalHeaderLabels(["Tarih", "Gerçek", "Tahmin", "Kalan Stok", "Eksik?"])

        stock_rows = []
        for i, (_, row) in enumerate(test_panel.iterrows()):
            forecast = float(row["pred"])
            shortage = stock < forecast
            self.ui.table.setItem(i, 0, QTableWidgetItem(str(row["date"].date())))
            self.ui.table.setItem(i, 1, QTableWidgetItem(f"{row['sales']:.2f}"))
            self.ui.table.setItem(i, 2, QTableWidgetItem(f"{forecast:.2f}"))
            self.ui.table.setItem(i, 3, QTableWidgetItem(f"{stock:.0f}"))
            self.ui.table.setItem(i, 4, QTableWidgetItem("Evet" if shortage else "Hayır"))
            stock_rows.append((item_id, store_id, row["date"].date(), int(stock), forecast, shortage))
            stock -= forecast

        try:
            conn = psycopg2.connect(host="localhost", database="salesdb", user="postgres", password="postgres", port=5432)
            cur = conn.cursor()
            for row in stock_rows:
                cur.execute("""
                    INSERT INTO stock_levels (item_id, store_id, stock_date, stock_quantity, forecasted_sales, shortage)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON CONFLICT (item_id, store_id, stock_date) DO UPDATE
                    SET stock_quantity = EXCLUDED.stock_quantity,
                        forecasted_sales = EXCLUDED.forecasted_sales,
                        shortage = EXCLUDED.shortage;
                """, row)
            conn.commit()
            cur.close()
            conn.close()
        except Exception as e:
            QMessageBox.warning(self, "Veritabanı Hatası", f"Stok kayıt edilemedi:\n{e}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ForecastApp()
    window.show()
    sys.exit(app.exec_())
