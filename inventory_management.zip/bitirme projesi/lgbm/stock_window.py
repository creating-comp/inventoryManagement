from PyQt5.QtWidgets import QWidget, QMessageBox
import psycopg2
from stok_tab_ui import Ui_StockWidget  # .ui dosyasını py'ye çevirdiysen bu doğru

class StockWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_StockWidget()
        self.ui.setupUi(self)

        # Verileri yükle
        self.load_products()
        self.load_stores()

        # Buton bağlantısı
        self.ui.saveStockButton.clicked.connect(self.save_stock)

        # Ürün değişince stok kontrol et
        self.ui.productCombo.currentTextChanged.connect(self.check_stock_level)
        self.ui.storeCombo.currentTextChanged.connect(self.check_stock_level)

    def load_products(self):
        try:
            conn = psycopg2.connect(host="localhost", database="salesdb", user="postgres", password="postgres", port=5432)
            cur = conn.cursor()
            cur.execute("SELECT DISTINCT product_name FROM product_stocks ORDER BY product_name;")
            products = cur.fetchall()
            self.ui.productCombo.clear()
            for prod in products:
                self.ui.productCombo.addItem(prod[0])
            cur.close()
            conn.close()
        except Exception as e:
            QMessageBox.warning(self, "Hata", f"Ürünler yüklenemedi:\n{e}")

    def load_stores(self):
        try:
            conn = psycopg2.connect(host="localhost", database="salesdb", user="postgres", password="postgres", port=5432)
            cur = conn.cursor()
            cur.execute("SELECT DISTINCT store_name FROM product_stocks ORDER BY store_name;")
            stores = cur.fetchall()
            self.ui.storeCombo.clear()
            for store in stores:
                self.ui.storeCombo.addItem(store[0])
            cur.close()
            conn.close()
        except Exception as e:
            QMessageBox.warning(self, "Hata", f"Mağazalar yüklenemedi:\n{e}")

    def check_stock_level(self):
        product = self.ui.productCombo.currentText()
        store = self.ui.storeCombo.currentText()

        if not product or not store:
            return

        try:
            conn = psycopg2.connect(host="localhost", database="salesdb", user="postgres", password="postgres", port=5432)
            cur = conn.cursor()
            cur.execute("""
                SELECT stock_quantity FROM product_stocks
                WHERE product_name = %s AND store_name = %s;
            """, (product, store))
            result = cur.fetchone()
            if result:
                qty = result[0]
                self.ui.stockSpinBox.setValue(qty)
                if qty < 50:
                    self.ui.criticalStockLabel.setText("⚠️ Kritik stok seviyesi!")
                else:
                    self.ui.criticalStockLabel.setText("")
            else:
                self.ui.stockSpinBox.setValue(0)
                self.ui.criticalStockLabel.setText("⚠️ Kayıt bulunamadı, yeni stok giriniz.")
            cur.close()
            conn.close()
        except Exception as e:
            QMessageBox.warning(self, "Veritabanı Hatası", f"Stok kontrol edilemedi:\n{e}")

    def save_stock(self):
        product = self.ui.productCombo.currentText()
        store = self.ui.storeCombo.currentText()
        qty = self.ui.stockSpinBox.value()

        if not product or not store:
            QMessageBox.warning(self, "Uyarı", "Ürün ve mağaza seçilmelidir.")
            return

        try:
            conn = psycopg2.connect(host="localhost", database="salesdb", user="postgres", password="postgres", port=5432)
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO product_stocks (product_name, store_name, stock_quantity)
                VALUES (%s, %s, %s)
                ON CONFLICT (product_name, store_name)
                DO UPDATE SET stock_quantity = EXCLUDED.stock_quantity;
            """, (product, store, qty))
            conn.commit()
            cur.close()
            conn.close()
            QMessageBox.information(self, "Başarılı", "Stok bilgisi kaydedildi.")
            self.check_stock_level()
        except Exception as e:
            QMessageBox.warning(self, "Veritabanı Hatası", f"Stok güncellenemedi:\n{e}")
