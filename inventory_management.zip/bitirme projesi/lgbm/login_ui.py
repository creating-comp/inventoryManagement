from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_LoginWindow(object):
    def setupUi(self, LoginWindow):
        LoginWindow.setObjectName("LoginWindow")
        LoginWindow.resize(400, 300)
        LoginWindow.setWindowTitle("Giriş Ekranı")
        LoginWindow.setStyleSheet("""
            QWidget {
                background-color: #f0f4f8;
                font-family: 'Century Gothic';
                font-size: 16px;
            }
            QLineEdit {
                padding: 6px;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QPushButton {
                background-color: #2b4f81;
                color: white;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #3a5f9b;
            }
        """)

        self.verticalLayout = QtWidgets.QVBoxLayout(LoginWindow)

        self.titleLabel = QtWidgets.QLabel("Satış Tahmini Giriş")
        self.titleLabel.setAlignment(QtCore.Qt.AlignCenter)
        font = QtGui.QFont()
        font.setPointSize(18)
        font.setBold(True)
        self.titleLabel.setFont(font)
        self.verticalLayout.addWidget(self.titleLabel)

        self.usernameInput = QtWidgets.QLineEdit()
        self.usernameInput.setPlaceholderText("Kullanıcı Adı")
        self.verticalLayout.addWidget(self.usernameInput)

        self.passwordInput = QtWidgets.QLineEdit()
        self.passwordInput.setPlaceholderText("Şifre")
        self.passwordInput.setEchoMode(QtWidgets.QLineEdit.Password)
        self.verticalLayout.addWidget(self.passwordInput)

        self.loginButton = QtWidgets.QPushButton("Giriş Yap")
        self.verticalLayout.addWidget(self.loginButton)

        self.loginStatusLabel = QtWidgets.QLabel("")
        self.loginStatusLabel.setAlignment(QtCore.Qt.AlignCenter)
        self.verticalLayout.addWidget(self.loginStatusLabel)

        QtCore.QMetaObject.connectSlotsByName(LoginWindow)
