import sys
from PyQt5.QtWidgets import QApplication, QMessageBox
from login import LoginWindow
from forecast_gui import ForecastApp

def main():
    app = QApplication(sys.argv)

    login_window = LoginWindow()
    if login_window.exec_() == login_window.Accepted:
        forecast_window = ForecastApp()
        forecast_window.show()
        sys.exit(app.exec_())
    else:
        QMessageBox.warning(None, "Giriş Başarısız", "Uygulama kapatılıyor.")
        sys.exit()

if __name__ == "__main__":
    main()
