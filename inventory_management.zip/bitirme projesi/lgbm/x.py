import psycopg2

try:
    conn = psycopg2.connect(
        host="localhost",
        port=5432,
        database="salesdb",
        user="postgres",
        password="postgres"  # kendi şifreni yaz
    )
    print("✅ Bağlantı başarılı!")
    conn.close()
except Exception as e:
    print("❌ Bağlantı hatası:", e)
